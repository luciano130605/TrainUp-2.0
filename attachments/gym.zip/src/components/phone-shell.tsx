import type { ReactNode } from "react";

export function PhoneShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-chassis">
      <div className="relative flex h-dvh w-full flex-col overflow-hidden bg-bg text-fg sm:h-device sm:w-device sm:rounded-2xl sm:shadow-[var(--shadow-border),0_40px_80px_rgb(0_0_0_/_0.55)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 z-30 hidden h-11 items-center justify-between px-6 text-[11px] font-medium text-fg/80 sm:flex">
          <span className="tabular-nums">9:41</span>
          <span className="absolute left-1/2 top-1.5 h-5 w-24 -translate-x-1/2 rounded-full bg-chassis" />
          <span className="flex items-center gap-1">
            <span className="block h-2.5 w-4 rounded-sm bg-fg/70" />
            <span className="block h-2.5 w-5 rounded-sm bg-fg/85" />
          </span>
        </div>
        <div className="relative flex min-h-0 flex-1 flex-col">{children}</div>
      </div>
    </div>
  );
}
