import { Activity, Dumbbell, House, Timer, User } from "lucide-react";
import type { Tab } from "@/lib/types";
import { cn } from "@/lib/utils";

const ITEMS: { id: Tab; label: string; icon: typeof House }[] = [
  { id: "home", label: "Inicio", icon: House },
  { id: "train", label: "Entrenar", icon: Dumbbell },
  { id: "timer", label: "Timer", icon: Timer },
  { id: "progress", label: "Progreso", icon: Activity },
  { id: "profile", label: "Yo", icon: User },
];

export function TabBar({ tab, onChange }: { tab: Tab; onChange: (tab: Tab) => void }) {
  return (
    <nav className="safe-bottom shrink-0 border-t border-line bg-surface/95 px-2 pt-1.5 pb-1">
      <ul className="grid grid-cols-5">
        {ITEMS.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onChange(item.id)}
                className={cn(
                  "flex h-14 w-full flex-col items-center justify-center gap-0.5 rounded-md pressable",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.4 : 1.8} />
                <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
