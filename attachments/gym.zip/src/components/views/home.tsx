import { ChevronRight, Flame, Trophy } from "lucide-react";
import type { ReactNode } from "react";
import { isToday } from "date-fns";
import { COVER_SRC } from "@/lib/routines";
import { firstName, formatDuration, formatVolume, formatWeight, greeting, longDate } from "@/lib/format";
import { computeStreak, todaysRoutine, useTrain } from "@/lib/store";
import { Button } from "../ui/button";
import { Ring } from "../ring";

export function HomeView() {
  const profile = useTrain((s) => s.profile);
  const history = useTrain((s) => s.history);
  const extras = useTrain((s) => s.customRoutines);
  const records = useTrain((s) => s.records);
  const startRoutine = useTrain((s) => s.startRoutine);
  const setTab = useTrain((s) => s.setTab);
  const lastSummary = useTrain((s) => s.lastSummary);

  const today = todaysRoutine(profile, history, extras);
  const streak = computeStreak(history);
  const weekStart = startOfLocalWeek();
  const weekSessions = history.filter((h) => h.endedAt >= weekStart);
  const trainedToday = history.some((h) => isToday(h.endedAt));
  const weekVol = weekSessions.reduce((s, h) => s + h.volumeKg, 0);
  const last = history[0];
  const latestPr = records[0];

  return (
    <div className="stagger-in space-y-6 pb-8">
      <header className="flex items-end justify-between pt-2">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-muted">{longDate()}</p>
          <h1 className="mt-1 font-display text-4xl leading-none tracking-tight">
            {greeting()}, {firstName(profile.name)}
          </h1>
        </div>
        <Ring
          value={weekSessions.length / profile.daysPerWeek}
          label={`${weekSessions.length}/${profile.daysPerWeek}`}
          sub="semana"
        />
      </header>

      {lastSummary ? (
        <div className="rounded-xl bg-elevated px-4 py-3 shadow-[var(--shadow-border)]">
          <p className="text-xs uppercase tracking-wider text-accent">Sesión cerrada</p>
          <p className="mt-1 font-medium">{lastSummary.routineName}</p>
          <p className="text-sm text-muted">
            {formatDuration(lastSummary.endedAt - lastSummary.startedAt)} ·{" "}
            {formatVolume(lastSummary.volumeKg, profile.unit)} · {lastSummary.setsCompleted} series
            {lastSummary.prs.length ? ` · ${lastSummary.prs.length} PR` : ""}
          </p>
        </div>
      ) : null}

      {today ? (
        <button
          type="button"
          onClick={() => startRoutine(today)}
          className="group relative block w-full overflow-hidden rounded-2xl text-left pressable"
        >
          <img
            src={COVER_SRC[today.cover]}
            alt=""
            className="media h-56 w-full object-cover transition-transform duration-500 group-active:scale-105"
          />
          <div className="absolute inset-0 bg-linear-to-t from-bg via-bg/50 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-accent">
              {trainedToday ? "Hecho hoy" : "Hoy"}
            </p>
            <h2 className="mt-1 font-display text-4xl leading-none">{today.name}</h2>
            <p className="mt-1 text-sm text-fg/80">
              {today.focus} · {today.durationMin} min · {today.exercises.length} ejercicios
            </p>
            <span className="mt-4 inline-flex h-11 items-center rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg">
              {trainedToday ? "Repetir sesión" : "Empezar"}
            </span>
          </div>
        </button>
      ) : null}

      <section className="grid grid-cols-3 gap-2">
        <Stat label="Racha" value={`${streak}d`} icon={<Flame className="size-3.5" />} />
        <Stat label="Volumen" value={formatVolume(weekVol, profile.unit)} />
        <Stat
          label="PRs"
          value={String(records.length)}
          icon={<Trophy className="size-3.5" />}
        />
      </section>

      {last ? (
        <section>
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-xs uppercase tracking-[0.18em] text-muted">Última sesión</h3>
            <button
              type="button"
              className="flex items-center gap-0.5 text-xs text-muted"
              onClick={() => setTab("progress")}
            >
              Historial <ChevronRight className="size-3.5" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => setTab("progress")}
            className="flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3.5 text-left shadow-[var(--shadow-border)] pressable"
          >
            <div>
              <p className="font-medium">{last.routineName}</p>
              <p className="text-sm text-muted">
                {formatVolume(last.volumeKg, profile.unit)} · {last.setsCompleted} series
              </p>
            </div>
            <p className="text-sm tabular-nums text-muted">
              {formatDuration(last.endedAt - last.startedAt)}
            </p>
          </button>
        </section>
      ) : (
        <p className="text-sm text-muted">El primer entrenamiento es el que cuenta.</p>
      )}

      {latestPr ? (
        <p className="text-xs text-muted">
          Mejor marca reciente · {formatWeight(latestPr.weightKg, profile.unit)} × {latestPr.reps}
        </p>
      ) : null}

      <Button variant="secondary" block onClick={() => setTab("train")}>
        Ver todas las rutinas
      </Button>
    </div>
  );
}

function Stat({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]">
      <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted">
        {icon}
        {label}
      </p>
      <p className="mt-1 font-display text-2xl leading-none tabular-nums">{value}</p>
    </div>
  );
}

function startOfLocalWeek() {
  const d = new Date();
  const day = d.getDay();
  const diff = (day + 6) % 7;
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - diff);
  return d.getTime();
}
