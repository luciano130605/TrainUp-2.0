import { useState, type ReactNode } from "react";
import { GOAL_LABEL, LEVEL_LABEL, formatWeight, fromDisplayWeight, toDisplayWeight } from "@/lib/format";
import type { Goal, Level, Unit } from "@/lib/types";
import { useTrain } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";
import { Mark } from "../mark";

const GOALS: Goal[] = ["fuerza", "hipertrofia", "definicion", "resistencia"];
const LEVELS: Level[] = ["principiante", "intermedio", "avanzado"];
const DAYS: Array<3 | 4 | 5 | 6> = [3, 4, 5, 6];

export function ProfileView() {
  const profile = useTrain((s) => s.profile);
  const history = useTrain((s) => s.history);
  const update = useTrain((s) => s.updateProfile);
  const addBodyLog = useTrain((s) => s.addBodyLog);
  const resetAll = useTrain((s) => s.resetAll);
  const [weight, setWeight] = useState(String(toDisplayWeight(profile.bodyWeightKg, profile.unit)));
  const [confirm, setConfirm] = useState(false);

  function saveWeight() {
    const n = Number(weight);
    if (!Number.isFinite(n) || n <= 0) return;
    addBodyLog(fromDisplayWeight(n, profile.unit));
  }

  function setUnit(unit: Unit) {
    update({ unit });
    setWeight(String(toDisplayWeight(profile.bodyWeightKg, unit)));
  }

  return (
    <div className="space-y-7 pb-10">
      <header className="flex items-center gap-4">
        <div className="flex size-14 items-center justify-center rounded-xl bg-elevated shadow-[var(--shadow-border)]">
          <Mark />
        </div>
        <div>
          <h1 className="font-display text-4xl leading-none tracking-tight">{profile.name}</h1>
          <p className="mt-1 text-sm text-muted">
            {GOAL_LABEL[profile.goal]} · {LEVEL_LABEL[profile.level]} · {history.length} sesiones
          </p>
        </div>
      </header>

      <Field label="Nombre">
        <input
          value={profile.name}
          onChange={(e) => update({ name: e.target.value })}
          className="h-12 w-full rounded-xl bg-elevated px-4 shadow-[var(--shadow-border)] outline-none"
        />
      </Field>

      <Field label="Objetivo">
        <div className="grid grid-cols-2 gap-2">
          {GOALS.map((g) => (
            <Chip key={g} active={profile.goal === g} onClick={() => update({ goal: g })}>
              {GOAL_LABEL[g]}
            </Chip>
          ))}
        </div>
      </Field>

      <Field label="Nivel">
        <div className="grid grid-cols-3 gap-2">
          {LEVELS.map((l) => (
            <Chip key={l} active={profile.level === l} onClick={() => update({ level: l })}>
              {LEVEL_LABEL[l]}
            </Chip>
          ))}
        </div>
      </Field>

      <Field label="Días por semana">
        <div className="grid grid-cols-4 gap-2">
          {DAYS.map((d) => (
            <Chip key={d} active={profile.daysPerWeek === d} onClick={() => update({ daysPerWeek: d })}>
              {d}
            </Chip>
          ))}
        </div>
      </Field>

      <Field label="Unidad">
        <div className="grid grid-cols-2 gap-2">
          <Chip active={profile.unit === "kg"} onClick={() => setUnit("kg")}>
            Kilogramos
          </Chip>
          <Chip active={profile.unit === "lb"} onClick={() => setUnit("lb")}>
            Libras
          </Chip>
        </div>
      </Field>

      <Field label={`Peso corporal (${profile.unit})`}>
        <div className="flex gap-2">
          <input
            inputMode="decimal"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="h-12 flex-1 rounded-xl bg-elevated px-4 tabular-nums shadow-[var(--shadow-border)] outline-none"
          />
          <Button onClick={saveWeight}>Guardar</Button>
        </div>
        <p className="mt-2 text-xs text-muted">
          Actual: {formatWeight(profile.bodyWeightKg, profile.unit)}
        </p>
      </Field>

      <section className="rounded-2xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
        <p className="text-sm text-muted">
          TrainUp guarda todo en este dispositivo. Añádela a tu pantalla de inicio para usarla como app.
        </p>
      </section>

      {confirm ? (
        <div className="space-y-2">
          <p className="text-sm text-danger">Esto borra historial, PRs y el perfil.</p>
          <div className="flex gap-2">
            <Button variant="secondary" className="flex-1" onClick={() => setConfirm(false)}>
              Cancelar
            </Button>
            <Button variant="danger" className="flex-1" onClick={resetAll}>
              Borrar
            </Button>
          </div>
        </div>
      ) : (
        <Button variant="ghost" block onClick={() => setConfirm(true)}>
          Borrar datos locales
        </Button>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <section>
      <p className="mb-2 text-xs uppercase tracking-[0.18em] text-muted">{label}</p>
      {children}
    </section>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 rounded-lg text-sm font-medium pressable shadow-[var(--shadow-border)]",
        active ? "bg-accent text-accent-fg" : "bg-elevated text-fg",
      )}
    >
      {children}
    </button>
  );
}
