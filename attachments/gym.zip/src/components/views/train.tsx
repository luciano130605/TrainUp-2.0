import { useMemo, useState } from "react";
import { Plus, Search, Trash2 } from "lucide-react";
import { COVER_SRC, filterRoutines } from "@/lib/routines";
import { EQUIPMENT_LABEL, getExercise, MUSCLE_LABEL, searchExercises } from "@/lib/exercises";
import { LEVEL_LABEL } from "@/lib/format";
import { useTrain } from "@/lib/store";
import type { Muscle, Routine, RoutineExercise } from "@/lib/types";
import { uid } from "@/lib/utils";
import { Button } from "../ui/button";
import { cn } from "@/lib/utils";

const MUSCLES: Array<Muscle | "todos"> = [
  "todos",
  "pecho",
  "espalda",
  "hombros",
  "piernas",
  "gluteos",
  "biceps",
  "triceps",
  "core",
  "cardio",
];

export function TrainView() {
  const profile = useTrain((s) => s.profile);
  const extras = useTrain((s) => s.customRoutines);
  const startRoutine = useTrain((s) => s.startRoutine);
  const deleteCustom = useTrain((s) => s.deleteCustomRoutine);
  const [mode, setMode] = useState<"rutinas" | "libreria" | "crear">("rutinas");

  const catalog = filterRoutines(profile.level);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="pb-3">
        <h1 className="font-display text-4xl tracking-tight">Entrenar</h1>
        <div className="mt-3 grid grid-cols-3 gap-1 rounded-xl bg-surface p-1 shadow-[var(--shadow-border)]">
          {(
            [
              ["rutinas", "Rutinas"],
              ["libreria", "Librería"],
              ["crear", "Crear"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setMode(id)}
              className={cn(
                "h-10 rounded-lg text-sm font-medium pressable",
                mode === id ? "bg-elevated text-fg" : "text-muted",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      {mode === "rutinas" ? (
        <div className="space-y-3 pb-8 stagger-in">
          {extras.length > 0 ? (
            <p className="text-xs uppercase tracking-[0.18em] text-muted">Tuyas</p>
          ) : null}
          {extras.map((r) => (
            <RoutineCard
              key={r.id}
              routine={r}
              onStart={() => startRoutine(r)}
              onDelete={() => deleteCustom(r.id)}
            />
          ))}
          <p className="pt-2 text-xs uppercase tracking-[0.18em] text-muted">Programas</p>
          {catalog.map((r) => (
            <RoutineCard key={r.id} routine={r} onStart={() => startRoutine(r)} />
          ))}
        </div>
      ) : null}

      {mode === "libreria" ? <Library onPick={(id) => startSingle(id, startRoutine)} /> : null}
      {mode === "crear" ? <Creator onDone={() => setMode("rutinas")} /> : null}
    </div>
  );
}

function startSingle(exerciseId: string, start: (r: Routine) => void) {
  const ex = getExercise(exerciseId);
  start({
    id: `solo-${ex.id}`,
    name: ex.name,
    focus: MUSCLE_LABEL[ex.muscle],
    durationMin: 20,
    level: "intermedio",
    cover: "barbell",
    exercises: [{ exerciseId: ex.id, sets: ex.defaultSets, reps: ex.defaultReps, restSec: ex.restSec }],
  });
}

function RoutineCard({
  routine,
  onStart,
  onDelete,
}: {
  routine: Routine;
  onStart: () => void;
  onDelete?: () => void;
}) {
  return (
    <article className="overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)]">
      <button type="button" onClick={onStart} className="block w-full text-left pressable">
        <div className="relative h-28">
          <img src={COVER_SRC[routine.cover]} alt="" className="media h-full w-full object-cover" />
          <div className="absolute inset-0 bg-linear-to-t from-surface to-transparent" />
        </div>
        <div className="px-4 pb-4 pt-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl leading-none">{routine.name}</h2>
              <p className="mt-1 text-sm text-muted">
                {routine.focus} · {routine.durationMin} min · {LEVEL_LABEL[routine.level]}
              </p>
            </div>
            <span className="mt-0.5 rounded-full bg-elevated px-2.5 py-1 text-[11px] tabular-nums text-muted">
              {routine.exercises.length} ej.
            </span>
          </div>
        </div>
      </button>
      {onDelete ? (
        <div className="flex justify-end px-3 pb-3">
          <button
            type="button"
            onClick={onDelete}
            className="flex size-11 items-center justify-center rounded-lg text-muted pressable"
            aria-label="Eliminar rutina"
          >
            <Trash2 className="size-4" />
          </button>
        </div>
      ) : null}
    </article>
  );
}

export function Library({
  onPick,
  hideStartHint,
}: {
  onPick: (id: string) => void;
  hideStartHint?: boolean;
}) {
  const [q, setQ] = useState("");
  const [muscle, setMuscle] = useState<Muscle | "todos">("todos");
  const list = useMemo(() => searchExercises(q, muscle), [q, muscle]);

  return (
    <div className="pb-8">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar ejercicio"
          className="h-12 w-full rounded-xl bg-elevated pl-10 pr-3 text-sm shadow-[var(--shadow-border)] outline-none placeholder:text-subtle"
        />
      </div>
      <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
        {MUSCLES.map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMuscle(m)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3 text-xs font-medium pressable",
              muscle === m ? "bg-accent text-accent-fg" : "bg-elevated text-muted",
            )}
          >
            {m === "todos" ? "Todos" : MUSCLE_LABEL[m]}
          </button>
        ))}
      </div>
      {!hideStartHint ? (
        <p className="mt-3 text-xs text-muted">Toca para entrenar ese movimiento solo.</p>
      ) : null}
      <ul className="mt-3 space-y-2">
        {list.map((ex) => (
          <li key={ex.id}>
            <button
              type="button"
              onClick={() => onPick(ex.id)}
              className="flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-border)] pressable"
            >
              <span>
                <span className="block font-medium">{ex.name}</span>
                <span className="text-xs text-muted">
                  {MUSCLE_LABEL[ex.muscle]} · {EQUIPMENT_LABEL[ex.equipment]}
                </span>
              </span>
              <span className="text-xs tabular-nums text-muted">
                {ex.defaultSets}×{ex.defaultReps}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Creator({ onDone }: { onDone: () => void }) {
  const save = useTrain((s) => s.saveCustomRoutine);
  const [name, setName] = useState("Mi rutina");
  const [picked, setPicked] = useState<RoutineExercise[]>([]);
  const [open, setOpen] = useState(false);

  function add(id: string) {
    const ex = getExercise(id);
    setPicked((p) => [
      ...p,
      { exerciseId: id, sets: ex.defaultSets, reps: ex.defaultReps, restSec: ex.restSec },
    ]);
    setOpen(false);
  }

  function persist() {
    if (!name.trim() || picked.length === 0) return;
    save({
      id: uid("rut"),
      name: name.trim(),
      focus: "Personal",
      durationMin: Math.max(20, picked.length * 8),
      level: "intermedio",
      cover: "dumbbells",
      custom: true,
      exercises: picked,
    });
    onDone();
  }

  return (
    <div className="space-y-4 pb-8">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="h-12 w-full rounded-xl bg-elevated px-4 shadow-[var(--shadow-border)] outline-none"
      />
      <ul className="space-y-2">
        {picked.map((slot, i) => {
          const ex = getExercise(slot.exerciseId);
          return (
            <li
              key={`${slot.exerciseId}-${i}`}
              className="flex items-center justify-between rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
            >
              <span>
                <span className="block font-medium">{ex.name}</span>
                <span className="text-xs text-muted">
                  {slot.sets} × {slot.reps}
                </span>
              </span>
              <button
                type="button"
                className="size-11 text-muted"
                onClick={() => setPicked((p) => p.filter((_, idx) => idx !== i))}
                aria-label="Quitar"
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          );
        })}
      </ul>
      {open ? (
        <Library hideStartHint onPick={add} />
      ) : (
        <Button variant="secondary" block onClick={() => setOpen(true)}>
          <Plus className="size-4" />
          Añadir ejercicio
        </Button>
      )}
      <Button block disabled={!picked.length} onClick={persist}>
        Guardar rutina
      </Button>
    </div>
  );
}
