import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useTrain } from "@/lib/store";
import { PhoneShell } from "@/components/phone-shell";
import { Splash } from "@/components/splash";
import { Onboarding } from "@/components/onboarding";
import { TabBar } from "@/components/tab-bar";
import { HomeView } from "@/components/views/home";
import { TrainView } from "@/components/views/train";
import { SessionView } from "@/components/views/session";
import { TimerView } from "@/components/views/timer";
import { ProgressView } from "@/components/views/progress";
import { ProfileView } from "@/components/views/profile";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useTrain((s) => s.hydrated);
  const onboarded = useTrain((s) => s.profile.onboarded);
  const session = useTrain((s) => s.session);
  const tab = useTrain((s) => s.tab);
  const setTab = useTrain((s) => s.setTab);
  const skipRest = useTrain((s) => s.skipRest);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        await Promise.resolve(useTrain.persist.rehydrate());
      } catch {
        /* empty store is fine */
      }
      if (!alive) return;
      const rest = useTrain.getState().session?.restUntil;
      if (rest && rest < Date.now()) skipRest();
      useTrain.getState().markHydrated();
    })();
    return () => {
      alive = false;
    };
  }, [skipRest]);

  return (
    <PhoneShell>
      {!hydrated ? (
        <Splash />
      ) : !onboarded ? (
        <Onboarding />
      ) : session ? (
        <SessionView />
      ) : (
        <div className="flex min-h-0 flex-1 flex-col">
          <main className="min-h-0 flex-1 overflow-y-auto px-5 pt-12">
            {tab === "home" ? <HomeView /> : null}
            {tab === "train" ? <TrainView /> : null}
            {tab === "timer" ? <TimerView /> : null}
            {tab === "progress" ? <ProgressView /> : null}
            {tab === "profile" ? <ProfileView /> : null}
          </main>
          <TabBar tab={tab} onChange={setTab} />
        </div>
      )}
    </PhoneShell>
  );
}
