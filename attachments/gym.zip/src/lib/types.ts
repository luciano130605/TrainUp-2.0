export type Goal = "fuerza" | "hipertrofia" | "definicion" | "resistencia";
export type Level = "principiante" | "intermedio" | "avanzado";
export type Unit = "kg" | "lb";
export type Tab = "home" | "train" | "timer" | "progress" | "profile";
export type Muscle =
  | "pecho"
  | "espalda"
  | "hombros"
  | "piernas"
  | "gluteos"
  | "biceps"
  | "triceps"
  | "core"
  | "cardio";
export type Equipment =
  | "barra"
  | "mancuernas"
  | "maquina"
  | "peso-corporal"
  | "kettlebell"
  | "polea"
  | "banco";

export type Exercise = {
  id: string;
  name: string;
  muscle: Muscle;
  secondary?: Muscle[];
  equipment: Equipment;
  cues: string[];
  defaultSets: number;
  defaultReps: number;
  restSec: number;
  compound: boolean;
};

export type RoutineExercise = {
  exerciseId: string;
  sets: number;
  reps: number;
  restSec: number;
};

export type Routine = {
  id: string;
  name: string;
  focus: string;
  durationMin: number;
  level: Level;
  cover: "hero" | "barbell" | "kettlebell" | "dumbbells";
  exercises: RoutineExercise[];
  custom?: boolean;
};

export type Profile = {
  name: string;
  goal: Goal;
  level: Level;
  daysPerWeek: 3 | 4 | 5 | 6;
  unit: Unit;
  bodyWeightKg: number;
  onboarded: boolean;
};

export type WorkoutSet = {
  id: string;
  reps: number;
  weightKg: number;
  completed: boolean;
};

export type SessionExercise = {
  exerciseId: string;
  restSec: number;
  notes: string;
  sets: WorkoutSet[];
};

export type ActiveSession = {
  routineId: string;
  routineName: string;
  startedAt: number;
  exercises: SessionExercise[];
  currentIndex: number;
  restUntil: number | null;
  restTotalSec: number;
};

export type LoggedSet = {
  reps: number;
  weightKg: number;
};

export type LoggedExercise = {
  exerciseId: string;
  sets: LoggedSet[];
};

export type CompletedSession = {
  id: string;
  routineId: string;
  routineName: string;
  startedAt: number;
  endedAt: number;
  volumeKg: number;
  setsCompleted: number;
  exercises: LoggedExercise[];
  prs: string[];
};

export type BodyLog = {
  date: string;
  weightKg: number;
};

export type PersonalRecord = {
  exerciseId: string;
  weightKg: number;
  reps: number;
  e1rm: number;
  date: string;
};

export type TimerMode = "descanso" | "tabata" | "emom" | "amrap" | "cronometro";
