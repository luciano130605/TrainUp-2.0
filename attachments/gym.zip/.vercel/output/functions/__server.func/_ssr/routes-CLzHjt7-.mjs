import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronRight, a as Trash2, b as Activity, c as RotateCcw, d as Play, f as Pause, g as Dumbbell, h as Flame, l as Replace, m as House, n as User, o as Timer, p as Minus, r as Trophy, s as Search, t as X, u as Plus, v as ChevronLeft, y as Check } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { a as startOfWeek, i as format, n as subDays, r as isToday, t as es } from "../_libs/date-fns.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLzHjt7-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MUSCLE_LABEL = {
	pecho: "Pecho",
	espalda: "Espalda",
	hombros: "Hombros",
	piernas: "Piernas",
	gluteos: "Glúteos",
	biceps: "Bíceps",
	triceps: "Tríceps",
	core: "Core",
	cardio: "Cardio"
};
var EQUIPMENT_LABEL = {
	barra: "Barra",
	mancuernas: "Mancuernas",
	maquina: "Máquina",
	"peso-corporal": "Peso corporal",
	kettlebell: "Kettlebell",
	polea: "Polea",
	banco: "Banco"
};
var EXERCISES = [
	{
		id: "press-banca",
		name: "Press de banca",
		muscle: "pecho",
		secondary: ["triceps", "hombros"],
		equipment: "barra",
		cues: [
			"Escápulas juntas",
			"Pies firmes",
			"Barra al pecho medio"
		],
		defaultSets: 4,
		defaultReps: 8,
		restSec: 150,
		compound: true
	},
	{
		id: "press-inclinado",
		name: "Press inclinado",
		muscle: "pecho",
		secondary: ["hombros", "triceps"],
		equipment: "barra",
		cues: [
			"Banco a 30°",
			"Recorrido controlado",
			"No rebotar"
		],
		defaultSets: 4,
		defaultReps: 8,
		restSec: 120,
		compound: true
	},
	{
		id: "press-mancuernas",
		name: "Press con mancuernas",
		muscle: "pecho",
		secondary: ["triceps"],
		equipment: "mancuernas",
		cues: [
			"Muñecas neutras",
			"Rango amplio",
			"Pausa arriba"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 90,
		compound: true
	},
	{
		id: "aperturas",
		name: "Aperturas",
		muscle: "pecho",
		equipment: "mancuernas",
		cues: [
			"Codo suave",
			"Estirar sin dolor",
			"Apriete al cierre"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 60,
		compound: false
	},
	{
		id: "fondos",
		name: "Fondos",
		muscle: "pecho",
		secondary: ["triceps"],
		equipment: "peso-corporal",
		cues: [
			"Torso levemente inclinado",
			"Hombros abajo",
			"Rango cómodo"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 90,
		compound: true
	},
	{
		id: "cruce-poleas",
		name: "Cruce de poleas",
		muscle: "pecho",
		equipment: "polea",
		cues: [
			"Paso estable",
			"Codos altos",
			"Apriete de 1s"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 60,
		compound: false
	},
	{
		id: "dominadas",
		name: "Dominadas",
		muscle: "espalda",
		secondary: ["biceps"],
		equipment: "peso-corporal",
		cues: [
			"Hombros lejos de las orejas",
			"Pecho a la barra",
			"Bajada lenta"
		],
		defaultSets: 4,
		defaultReps: 6,
		restSec: 150,
		compound: true
	},
	{
		id: "jalon",
		name: "Jalón al pecho",
		muscle: "espalda",
		secondary: ["biceps"],
		equipment: "polea",
		cues: [
			"Pecho alto",
			"Tirar con los codos",
			"No balancear"
		],
		defaultSets: 4,
		defaultReps: 10,
		restSec: 90,
		compound: true
	},
	{
		id: "remo-barra",
		name: "Remo con barra",
		muscle: "espalda",
		secondary: ["biceps"],
		equipment: "barra",
		cues: [
			"Espalda neutra",
			"Barra al ombligo",
			"Pausa 1s"
		],
		defaultSets: 4,
		defaultReps: 8,
		restSec: 120,
		compound: true
	},
	{
		id: "remo-mancuerna",
		name: "Remo con mancuerna",
		muscle: "espalda",
		secondary: ["biceps"],
		equipment: "mancuernas",
		cues: [
			"Mano y rodilla en banco",
			"Codo pegado",
			"Sin rotar el torso"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 75,
		compound: true
	},
	{
		id: "peso-muerto",
		name: "Peso muerto",
		muscle: "espalda",
		secondary: ["piernas", "gluteos"],
		equipment: "barra",
		cues: [
			"Barra pegada",
			"Dorsal activo",
			"Caderas atrás"
		],
		defaultSets: 4,
		defaultReps: 5,
		restSec: 180,
		compound: true
	},
	{
		id: "face-pull",
		name: "Face pull",
		muscle: "espalda",
		secondary: ["hombros"],
		equipment: "polea",
		cues: [
			"Cuerda a la cara",
			"Rotación externa",
			"Escápulas juntas"
		],
		defaultSets: 3,
		defaultReps: 15,
		restSec: 45,
		compound: false
	},
	{
		id: "press-militar",
		name: "Press militar",
		muscle: "hombros",
		secondary: ["triceps"],
		equipment: "barra",
		cues: [
			"Core cerrado",
			"Cabeza atrás al subir",
			"No hiperextender"
		],
		defaultSets: 4,
		defaultReps: 6,
		restSec: 150,
		compound: true
	},
	{
		id: "press-hombro-mancuernas",
		name: "Press de hombro",
		muscle: "hombros",
		secondary: ["triceps"],
		equipment: "mancuernas",
		cues: [
			"Muñecas sobre el codo",
			"Recorrido completo",
			"Sin impulso"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 90,
		compound: true
	},
	{
		id: "laterales",
		name: "Elevaciones laterales",
		muscle: "hombros",
		equipment: "mancuernas",
		cues: [
			"Meñique levemente arriba",
			"Sin trapecio",
			"Control al bajar"
		],
		defaultSets: 4,
		defaultReps: 12,
		restSec: 45,
		compound: false
	},
	{
		id: "pajaros",
		name: "Pájaros",
		muscle: "hombros",
		secondary: ["espalda"],
		equipment: "mancuernas",
		cues: [
			"Pecho adelante",
			"Pulgares ligeramente in",
			"Apriete posterior"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 45,
		compound: false
	},
	{
		id: "sentadilla",
		name: "Sentadilla",
		muscle: "piernas",
		secondary: ["gluteos", "core"],
		equipment: "barra",
		cues: [
			"Rodillas en línea",
			"Pecho alto",
			"Profundidad controlada"
		],
		defaultSets: 4,
		defaultReps: 6,
		restSec: 180,
		compound: true
	},
	{
		id: "prensa",
		name: "Prensa",
		muscle: "piernas",
		secondary: ["gluteos"],
		equipment: "maquina",
		cues: [
			"Pies medios",
			"No bloquear",
			"Rango sin despegar lumbar"
		],
		defaultSets: 4,
		defaultReps: 10,
		restSec: 120,
		compound: true
	},
	{
		id: "zancadas",
		name: "Zancadas",
		muscle: "piernas",
		secondary: ["gluteos"],
		equipment: "mancuernas",
		cues: [
			"Paso largo",
			"Torso erguido",
			"Rodilla estable"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 75,
		compound: true
	},
	{
		id: "bulgara",
		name: "Sentadilla búlgara",
		muscle: "piernas",
		secondary: ["gluteos"],
		equipment: "mancuernas",
		cues: [
			"Pie atrasero ligero",
			"Tibia vertical",
			"Bajada lenta"
		],
		defaultSets: 3,
		defaultReps: 8,
		restSec: 90,
		compound: true
	},
	{
		id: "extension-cuad",
		name: "Extensión de cuádriceps",
		muscle: "piernas",
		equipment: "maquina",
		cues: [
			"Pausa arriba",
			"Sin balanceo",
			"Control total"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 60,
		compound: false
	},
	{
		id: "curl-femoral",
		name: "Curl femoral",
		muscle: "piernas",
		equipment: "maquina",
		cues: [
			"Cadera pegada",
			"Apriete 1s",
			"Estirar sin rebotar"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 60,
		compound: false
	},
	{
		id: "rumano",
		name: "Peso muerto rumano",
		muscle: "piernas",
		secondary: ["gluteos", "espalda"],
		equipment: "barra",
		cues: [
			"Caderas atrás",
			"Barra pegada",
			"Rodillas suaves"
		],
		defaultSets: 3,
		defaultReps: 8,
		restSec: 120,
		compound: true
	},
	{
		id: "hip-thrust",
		name: "Hip thrust",
		muscle: "gluteos",
		secondary: ["piernas"],
		equipment: "barra",
		cues: [
			"Mentón metido",
			"Apriete arriba",
			"Costillas abajo"
		],
		defaultSets: 4,
		defaultReps: 8,
		restSec: 90,
		compound: true
	},
	{
		id: "gemelos",
		name: "Elevación de gemelos",
		muscle: "piernas",
		equipment: "maquina",
		cues: [
			"Pausa arriba",
			"Estirar abajo",
			"Sin rebotar"
		],
		defaultSets: 4,
		defaultReps: 12,
		restSec: 45,
		compound: false
	},
	{
		id: "curl-biceps",
		name: "Curl de bíceps",
		muscle: "biceps",
		equipment: "barra",
		cues: [
			"Codos fijos",
			"Sin balanceo",
			"Bajada de 3s"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 60,
		compound: false
	},
	{
		id: "curl-martillo",
		name: "Curl martillo",
		muscle: "biceps",
		equipment: "mancuernas",
		cues: [
			"Agarre neutro",
			"Hombros quietos",
			"Rango completo"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 60,
		compound: false
	},
	{
		id: "extension-triceps",
		name: "Extensión de tríceps",
		muscle: "triceps",
		equipment: "polea",
		cues: [
			"Codos pegados",
			"Solo antebrazo",
			"Apriete abajo"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 45,
		compound: false
	},
	{
		id: "press-frances",
		name: "Press francés",
		muscle: "triceps",
		equipment: "barra",
		cues: [
			"Codos al techo",
			"Bajar a la frente",
			"Sin abrir"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 75,
		compound: false
	},
	{
		id: "plancha",
		name: "Plancha",
		muscle: "core",
		equipment: "peso-corporal",
		cues: [
			"Glúteo activo",
			"Costillas cerradas",
			"Cuello largo"
		],
		defaultSets: 3,
		defaultReps: 45,
		restSec: 45,
		compound: false
	},
	{
		id: "elevacion-piernas",
		name: "Elevación de piernas",
		muscle: "core",
		equipment: "peso-corporal",
		cues: [
			"Lumbar pegada",
			"Subir con control",
			"No balancear"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 45,
		compound: false
	},
	{
		id: "crunch",
		name: "Crunch",
		muscle: "core",
		equipment: "peso-corporal",
		cues: [
			"Exhalar al subir",
			"Mentón neutro",
			"Rango corto"
		],
		defaultSets: 3,
		defaultReps: 15,
		restSec: 30,
		compound: false
	},
	{
		id: "pallof",
		name: "Pallof press",
		muscle: "core",
		equipment: "polea",
		cues: [
			"Anti-rotación",
			"Caderas cuadradas",
			"Brazos largos"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 45,
		compound: false
	},
	{
		id: "russian-twist",
		name: "Russian twist",
		muscle: "core",
		equipment: "peso-corporal",
		cues: [
			"Pecho alto",
			"Girar desde el torso",
			"Talones ligeros"
		],
		defaultSets: 3,
		defaultReps: 16,
		restSec: 30,
		compound: false
	},
	{
		id: "farmer",
		name: "Farmer carry",
		muscle: "core",
		secondary: ["hombros"],
		equipment: "mancuernas",
		cues: [
			"Hombros abajo",
			"Pasos cortos",
			"Costillas cerradas"
		],
		defaultSets: 3,
		defaultReps: 40,
		restSec: 60,
		compound: true
	},
	{
		id: "kb-swing",
		name: "Swing de kettlebell",
		muscle: "gluteos",
		secondary: ["espalda", "core"],
		equipment: "kettlebell",
		cues: [
			"Bisagra, no sentadilla",
			"Snap de cadera",
			"Brazos relajados"
		],
		defaultSets: 4,
		defaultReps: 12,
		restSec: 60,
		compound: true
	},
	{
		id: "remo-erg",
		name: "Remo máquina cardio",
		muscle: "cardio",
		equipment: "maquina",
		cues: [
			"Piernas-torso-brazos",
			"Ritmo constante",
			"No encorvar"
		],
		defaultSets: 1,
		defaultReps: 10,
		restSec: 0,
		compound: true
	},
	{
		id: "burpees",
		name: "Burpees",
		muscle: "cardio",
		equipment: "peso-corporal",
		cues: [
			"Pecho al suelo",
			"Salto completo",
			"Ritmo sostenible"
		],
		defaultSets: 3,
		defaultReps: 10,
		restSec: 45,
		compound: true
	},
	{
		id: "sentadilla-goblet",
		name: "Sentadilla goblet",
		muscle: "piernas",
		secondary: ["gluteos", "core"],
		equipment: "kettlebell",
		cues: [
			"Codos adentro",
			"Talones firmes",
			"Torso alto"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 75,
		compound: true
	},
	{
		id: "flexiones",
		name: "Flexiones",
		muscle: "pecho",
		secondary: ["triceps", "core"],
		equipment: "peso-corporal",
		cues: [
			"Cuerpo en línea",
			"Codos 45°",
			"Pecho cerca del suelo"
		],
		defaultSets: 3,
		defaultReps: 12,
		restSec: 60,
		compound: true
	}
];
var byId = new Map(EXERCISES.map((e) => [e.id, e]));
function getExercise(id) {
	return byId.get(id) ?? EXERCISES[0];
}
function searchExercises(query, muscle) {
	const q = query.trim().toLowerCase();
	return EXERCISES.filter((e) => {
		const muscleOk = !muscle || muscle === "todos" || e.muscle === muscle;
		if (!q) return muscleOk;
		const hay = `${e.name} ${MUSCLE_LABEL[e.muscle]} ${e.equipment}`.toLowerCase();
		return muscleOk && hay.includes(q);
	});
}
var COVER_SRC = {
	hero: "/media/gym-hero.jpg",
	barbell: "/media/barbell.jpg",
	kettlebell: "/media/kettlebell.jpg",
	dumbbells: "/media/dumbbells.jpg"
};
var ROUTINES = [
	{
		id: "push",
		name: "Empuje",
		focus: "Pecho, hombros, tríceps",
		durationMin: 55,
		level: "intermedio",
		cover: "barbell",
		exercises: [
			{
				exerciseId: "press-banca",
				sets: 4,
				reps: 8,
				restSec: 150
			},
			{
				exerciseId: "press-inclinado",
				sets: 3,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "press-hombro-mancuernas",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "laterales",
				sets: 3,
				reps: 12,
				restSec: 45
			},
			{
				exerciseId: "fondos",
				sets: 3,
				reps: 8,
				restSec: 90
			},
			{
				exerciseId: "extension-triceps",
				sets: 3,
				reps: 12,
				restSec: 45
			}
		]
	},
	{
		id: "pull",
		name: "Jalón",
		focus: "Espalda y bíceps",
		durationMin: 55,
		level: "intermedio",
		cover: "dumbbells",
		exercises: [
			{
				exerciseId: "peso-muerto",
				sets: 3,
				reps: 5,
				restSec: 180
			},
			{
				exerciseId: "dominadas",
				sets: 4,
				reps: 6,
				restSec: 150
			},
			{
				exerciseId: "remo-barra",
				sets: 4,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "jalon",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "face-pull",
				sets: 3,
				reps: 15,
				restSec: 45
			},
			{
				exerciseId: "curl-biceps",
				sets: 3,
				reps: 10,
				restSec: 60
			}
		]
	},
	{
		id: "legs",
		name: "Piernas",
		focus: "Cuádriceps, femorales, glúteo",
		durationMin: 60,
		level: "intermedio",
		cover: "hero",
		exercises: [
			{
				exerciseId: "sentadilla",
				sets: 4,
				reps: 6,
				restSec: 180
			},
			{
				exerciseId: "rumano",
				sets: 3,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "prensa",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "bulgara",
				sets: 3,
				reps: 8,
				restSec: 90
			},
			{
				exerciseId: "curl-femoral",
				sets: 3,
				reps: 12,
				restSec: 60
			},
			{
				exerciseId: "gemelos",
				sets: 4,
				reps: 12,
				restSec: 45
			}
		]
	},
	{
		id: "upper",
		name: "Torso",
		focus: "Empuje y jalón en un bloque",
		durationMin: 50,
		level: "intermedio",
		cover: "dumbbells",
		exercises: [
			{
				exerciseId: "press-banca",
				sets: 4,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "remo-barra",
				sets: 4,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "press-militar",
				sets: 3,
				reps: 6,
				restSec: 120
			},
			{
				exerciseId: "jalon",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "laterales",
				sets: 3,
				reps: 12,
				restSec: 45
			},
			{
				exerciseId: "curl-martillo",
				sets: 2,
				reps: 10,
				restSec: 45
			}
		]
	},
	{
		id: "lower",
		name: "Inferior",
		focus: "Fuerza de tren inferior",
		durationMin: 50,
		level: "intermedio",
		cover: "kettlebell",
		exercises: [
			{
				exerciseId: "sentadilla",
				sets: 4,
				reps: 6,
				restSec: 180
			},
			{
				exerciseId: "rumano",
				sets: 3,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "hip-thrust",
				sets: 3,
				reps: 8,
				restSec: 90
			},
			{
				exerciseId: "zancadas",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "plancha",
				sets: 3,
				reps: 40,
				restSec: 45
			}
		]
	},
	{
		id: "full-a",
		name: "Cuerpo completo A",
		focus: "Patrones básicos",
		durationMin: 45,
		level: "principiante",
		cover: "hero",
		exercises: [
			{
				exerciseId: "sentadilla-goblet",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "press-mancuernas",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "remo-mancuerna",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "laterales",
				sets: 3,
				reps: 12,
				restSec: 45
			},
			{
				exerciseId: "plancha",
				sets: 3,
				reps: 30,
				restSec: 45
			}
		]
	},
	{
		id: "full-b",
		name: "Cuerpo completo B",
		focus: "Bisagra, empuje, core",
		durationMin: 45,
		level: "principiante",
		cover: "kettlebell",
		exercises: [
			{
				exerciseId: "rumano",
				sets: 3,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "flexiones",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "jalon",
				sets: 3,
				reps: 10,
				restSec: 90
			},
			{
				exerciseId: "hip-thrust",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "pallof",
				sets: 3,
				reps: 10,
				restSec: 45
			}
		]
	},
	{
		id: "full-c",
		name: "Cuerpo completo C",
		focus: "Densidad y control",
		durationMin: 40,
		level: "principiante",
		cover: "dumbbells",
		exercises: [
			{
				exerciseId: "prensa",
				sets: 3,
				reps: 12,
				restSec: 90
			},
			{
				exerciseId: "press-hombro-mancuernas",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "remo-mancuerna",
				sets: 3,
				reps: 10,
				restSec: 75
			},
			{
				exerciseId: "kb-swing",
				sets: 3,
				reps: 12,
				restSec: 60
			},
			{
				exerciseId: "crunch",
				sets: 3,
				reps: 15,
				restSec: 30
			}
		]
	},
	{
		id: "five-by-five",
		name: "Fuerza 5×5",
		focus: "Los tres grandes",
		durationMin: 50,
		level: "intermedio",
		cover: "barbell",
		exercises: [
			{
				exerciseId: "sentadilla",
				sets: 5,
				reps: 5,
				restSec: 180
			},
			{
				exerciseId: "press-banca",
				sets: 5,
				reps: 5,
				restSec: 180
			},
			{
				exerciseId: "remo-barra",
				sets: 5,
				reps: 5,
				restSec: 150
			}
		]
	},
	{
		id: "core-express",
		name: "Core express",
		focus: "15 minutos de tronco",
		durationMin: 15,
		level: "principiante",
		cover: "kettlebell",
		exercises: [
			{
				exerciseId: "plancha",
				sets: 3,
				reps: 40,
				restSec: 30
			},
			{
				exerciseId: "elevacion-piernas",
				sets: 3,
				reps: 12,
				restSec: 30
			},
			{
				exerciseId: "pallof",
				sets: 3,
				reps: 10,
				restSec: 30
			},
			{
				exerciseId: "russian-twist",
				sets: 3,
				reps: 16,
				restSec: 30
			}
		]
	},
	{
		id: "gluteos",
		name: "Glúteo y posterior",
		focus: "Cadena posterior",
		durationMin: 40,
		level: "intermedio",
		cover: "hero",
		exercises: [
			{
				exerciseId: "hip-thrust",
				sets: 4,
				reps: 8,
				restSec: 90
			},
			{
				exerciseId: "rumano",
				sets: 3,
				reps: 8,
				restSec: 120
			},
			{
				exerciseId: "bulgara",
				sets: 3,
				reps: 8,
				restSec: 75
			},
			{
				exerciseId: "kb-swing",
				sets: 3,
				reps: 12,
				restSec: 60
			},
			{
				exerciseId: "curl-femoral",
				sets: 3,
				reps: 12,
				restSec: 45
			}
		]
	},
	{
		id: "hiit",
		name: "Condición",
		focus: "Densidad y pulso",
		durationMin: 25,
		level: "avanzado",
		cover: "kettlebell",
		exercises: [
			{
				exerciseId: "kb-swing",
				sets: 5,
				reps: 15,
				restSec: 45
			},
			{
				exerciseId: "burpees",
				sets: 4,
				reps: 8,
				restSec: 45
			},
			{
				exerciseId: "farmer",
				sets: 3,
				reps: 40,
				restSec: 60
			},
			{
				exerciseId: "flexiones",
				sets: 3,
				reps: 12,
				restSec: 45
			}
		]
	}
];
var PLAN = {
	"fuerza-3": [
		"five-by-five",
		"full-b",
		"five-by-five"
	],
	"fuerza-4": [
		"five-by-five",
		"pull",
		"five-by-five",
		"legs"
	],
	"fuerza-5": [
		"five-by-five",
		"push",
		"legs",
		"pull",
		"five-by-five"
	],
	"fuerza-6": [
		"push",
		"pull",
		"legs",
		"push",
		"pull",
		"legs"
	],
	"hipertrofia-3": [
		"full-a",
		"full-b",
		"full-c"
	],
	"hipertrofia-4": [
		"upper",
		"lower",
		"upper",
		"lower"
	],
	"hipertrofia-5": [
		"push",
		"pull",
		"legs",
		"upper",
		"lower"
	],
	"hipertrofia-6": [
		"push",
		"pull",
		"legs",
		"push",
		"pull",
		"legs"
	],
	"definicion-3": [
		"full-a",
		"hiit",
		"full-c"
	],
	"definicion-4": [
		"upper",
		"hiit",
		"lower",
		"core-express"
	],
	"definicion-5": [
		"push",
		"pull",
		"hiit",
		"legs",
		"core-express"
	],
	"definicion-6": [
		"push",
		"pull",
		"legs",
		"hiit",
		"upper",
		"core-express"
	],
	"resistencia-3": [
		"full-a",
		"hiit",
		"full-c"
	],
	"resistencia-4": [
		"full-a",
		"hiit",
		"full-b",
		"core-express"
	],
	"resistencia-5": [
		"full-a",
		"hiit",
		"full-b",
		"core-express",
		"full-c"
	],
	"resistencia-6": [
		"full-a",
		"hiit",
		"full-b",
		"hiit",
		"full-c",
		"core-express"
	]
};
function getRoutine(id, extras = []) {
	return extras.find((r) => r.id === id) ?? ROUTINES.find((r) => r.id === id);
}
function planFor(goal, days) {
	return PLAN[`${goal}-${days}`] ?? PLAN["hipertrofia-4"];
}
function filterRoutines(level) {
	if (level === "principiante") return ROUTINES.filter((r) => r.level !== "avanzado");
	return ROUTINES;
}
var GOAL_LABEL = {
	fuerza: "Fuerza",
	hipertrofia: "Hipertrofia",
	definicion: "Definición",
	resistencia: "Resistencia"
};
var LEVEL_LABEL = {
	principiante: "Principiante",
	intermedio: "Intermedio",
	avanzado: "Avanzado"
};
function roundTo(n, step) {
	return Math.round(n / step) * step;
}
function toDisplayWeight(kg, unit) {
	if (unit === "kg") return roundTo(kg, .5);
	return roundTo(kg * 2.20462262, 1);
}
function fromDisplayWeight(value, unit) {
	if (unit === "kg") return value;
	return value / 2.20462262;
}
function weightStep(unit) {
	return unit === "kg" ? 2.5 : 5;
}
function formatWeight(kg, unit, withUnit = true) {
	const v = toDisplayWeight(kg, unit);
	const text = Number.isInteger(v) ? String(v) : v.toFixed(1);
	return withUnit ? `${text} ${unit}` : text;
}
function formatVolume(kg, unit) {
	const v = unit === "kg" ? kg : kg * 2.20462262;
	if (v >= 1e3) return `${(v / 1e3).toFixed(1)} t`;
	return `${Math.round(v)} ${unit}`;
}
function formatDuration(ms) {
	const total = Math.max(0, Math.round(ms / 1e3));
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function formatClock(totalSec) {
	const n = Math.max(0, Math.ceil(totalSec));
	const m = Math.floor(n / 60);
	const s = n % 60;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function greeting(now = /* @__PURE__ */ new Date()) {
	const h = now.getHours();
	if (h < 6) return "Buena madrugada";
	if (h < 12) return "Buenos días";
	if (h < 19) return "Buenas tardes";
	return "Buenas noches";
}
function longDate(ts = Date.now()) {
	return format(ts, "EEEE d MMMM", { locale: es });
}
function weekStart(ts = Date.now()) {
	return startOfWeek(ts, { weekStartsOn: 1 }).getTime();
}
function e1rm(weightKg, reps) {
	if (reps <= 1) return weightKg;
	return weightKg * (1 + reps / 30);
}
function firstName(name) {
	return name.trim().split(/\s+/)[0] || "atleta";
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}-${Date.now().toString(36)}`;
}
var defaultProfile = {
	name: "",
	goal: "hipertrofia",
	level: "intermedio",
	daysPerWeek: 4,
	unit: "kg",
	bodyWeightKg: 75,
	onboarded: false
};
function lastLoad(history, exerciseId) {
	for (const session of history) {
		const last = session.exercises.find((e) => e.exerciseId === exerciseId)?.sets.at(-1);
		if (last) return last;
	}
	return null;
}
function buildSession(routine, history) {
	return {
		routineId: routine.id,
		routineName: routine.name,
		startedAt: Date.now(),
		currentIndex: 0,
		restUntil: null,
		restTotalSec: 0,
		exercises: routine.exercises.map((slot) => {
			const ex = getExercise(slot.exerciseId);
			const weightKg = lastLoad(history, slot.exerciseId)?.weightKg ?? 0;
			const reps = slot.reps || ex.defaultReps;
			const sets = Array.from({ length: slot.sets }, () => ({
				id: uid("set"),
				reps,
				weightKg,
				completed: false
			}));
			return {
				exerciseId: slot.exerciseId,
				restSec: slot.restSec,
				notes: "",
				sets
			};
		})
	};
}
function volumeOf(session) {
	return session.exercises.reduce((sum, ex) => {
		return sum + ex.sets.reduce((s, set) => set.completed ? s + set.weightKg * set.reps : s, 0);
	}, 0);
}
function todaysRoutine(profile, history, extras) {
	const plan = planFor(profile.goal, profile.daysPerWeek);
	const start = weekStart();
	const doneThisWeek = history.filter((h) => h.endedAt >= start);
	if (history.some((h) => isToday(h.endedAt))) return getRoutine(plan[Math.min(doneThisWeek.length - 1, plan.length - 1)], extras) ?? getRoutine(plan[0], extras);
	return getRoutine(plan[Math.min(doneThisWeek.length, plan.length - 1)], extras);
}
function computeStreak(history) {
	if (history.length === 0) return 0;
	const days = new Set(history.map((h) => {
		const d = new Date(h.endedAt);
		return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
	}));
	let streak = 0;
	const cursor = /* @__PURE__ */ new Date();
	if (!days.has(`${cursor.getFullYear()}-${cursor.getMonth()}-${cursor.getDate()}`)) cursor.setDate(cursor.getDate() - 1);
	while (days.has(`${cursor.getFullYear()}-${cursor.getMonth()}-${cursor.getDate()}`)) {
		streak += 1;
		cursor.setDate(cursor.getDate() - 1);
	}
	return streak;
}
var useTrain = create()(persist((set, get) => ({
	hydrated: false,
	tab: "home",
	profile: defaultProfile,
	customRoutines: [],
	history: [],
	records: [],
	bodyLogs: [],
	session: null,
	lastSummary: null,
	timerMode: "descanso",
	markHydrated: () => set({ hydrated: true }),
	setTab: (tab) => set({ tab }),
	completeOnboarding: (input) => set({
		profile: {
			...input,
			onboarded: true
		},
		bodyLogs: [{
			date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			weightKg: input.bodyWeightKg
		}],
		tab: "home"
	}),
	updateProfile: (patch) => set((s) => ({ profile: {
		...s.profile,
		...patch
	} })),
	startRoutine: (routine) => set((s) => ({
		session: buildSession(routine, s.history),
		lastSummary: null
	})),
	discardSession: () => set({ session: null }),
	setCurrentExercise: (index) => set((s) => s.session ? { session: {
		...s.session,
		currentIndex: index,
		restUntil: null
	} } : {}),
	updateSet: (exerciseIndex, setId, patch) => set((s) => {
		if (!s.session) return {};
		const exercises = s.session.exercises.map((ex, i) => {
			if (i !== exerciseIndex) return ex;
			return {
				...ex,
				sets: ex.sets.map((st) => st.id === setId ? {
					...st,
					...patch
				} : st)
			};
		});
		return { session: {
			...s.session,
			exercises
		} };
	}),
	toggleSet: (exerciseIndex, setId) => set((s) => {
		if (!s.session) return {};
		const target = s.session.exercises[exerciseIndex];
		if (!target) return {};
		const was = target.sets.find((st) => st.id === setId)?.completed ?? false;
		const exercises = s.session.exercises.map((ex, i) => {
			if (i !== exerciseIndex) return ex;
			return {
				...ex,
				sets: ex.sets.map((st) => st.id === setId ? {
					...st,
					completed: !st.completed
				} : st)
			};
		});
		let restUntil = s.session.restUntil;
		let restTotalSec = s.session.restTotalSec;
		let currentIndex = s.session.currentIndex;
		if (!was) {
			restUntil = Date.now() + target.restSec * 1e3;
			restTotalSec = target.restSec;
			if (exercises[exerciseIndex].sets.every((st) => st.completed) && exerciseIndex < exercises.length - 1) currentIndex = exerciseIndex + 1;
		} else restUntil = null;
		return { session: {
			...s.session,
			exercises,
			restUntil,
			restTotalSec,
			currentIndex
		} };
	}),
	addSet: (exerciseIndex) => set((s) => {
		if (!s.session) return {};
		const exercises = s.session.exercises.map((ex, i) => {
			if (i !== exerciseIndex) return ex;
			const last = ex.sets.at(-1);
			return {
				...ex,
				sets: [...ex.sets, {
					id: uid("set"),
					reps: last?.reps ?? 8,
					weightKg: last?.weightKg ?? 0,
					completed: false
				}]
			};
		});
		return { session: {
			...s.session,
			exercises
		} };
	}),
	removeSet: (exerciseIndex, setId) => set((s) => {
		if (!s.session) return {};
		const exercises = s.session.exercises.map((ex, i) => {
			if (i !== exerciseIndex) return ex;
			if (ex.sets.length <= 1) return ex;
			return {
				...ex,
				sets: ex.sets.filter((st) => st.id !== setId)
			};
		});
		return { session: {
			...s.session,
			exercises
		} };
	}),
	replaceExercise: (exerciseIndex, exerciseId) => set((s) => {
		if (!s.session) return {};
		const ex = getExercise(exerciseId);
		const prev = lastLoad(s.history, exerciseId);
		const exercises = s.session.exercises.map((item, i) => {
			if (i !== exerciseIndex) return item;
			return {
				exerciseId,
				restSec: ex.restSec,
				notes: "",
				sets: Array.from({ length: Math.max(item.sets.length, ex.defaultSets) }, () => ({
					id: uid("set"),
					reps: ex.defaultReps,
					weightKg: prev?.weightKg ?? 0,
					completed: false
				}))
			};
		});
		return { session: {
			...s.session,
			exercises,
			restUntil: null
		} };
	}),
	skipRest: () => set((s) => s.session ? { session: {
		...s.session,
		restUntil: null
	} } : {}),
	addRest: (sec) => set((s) => {
		if (!s.session) return {};
		const base = s.session.restUntil && s.session.restUntil > Date.now() ? s.session.restUntil : Date.now();
		return { session: {
			...s.session,
			restUntil: base + sec * 1e3,
			restTotalSec: s.session.restTotalSec + sec
		} };
	}),
	finishSession: () => {
		const s = get();
		if (!s.session) return null;
		const endedAt = Date.now();
		const exercises = s.session.exercises.map((ex) => ({
			exerciseId: ex.exerciseId,
			sets: ex.sets.filter((st) => st.completed && (st.weightKg > 0 || st.reps > 0)).map((st) => ({
				reps: st.reps,
				weightKg: st.weightKg
			}))
		})).filter((ex) => ex.sets.length > 0);
		const setsCompleted = exercises.reduce((n, ex) => n + ex.sets.length, 0);
		if (setsCompleted === 0) {
			set({ session: null });
			return null;
		}
		const volumeKg = volumeOf({ exercises: s.session.exercises });
		const records = [...s.records];
		const prs = [];
		for (const ex of exercises) for (const st of ex.sets) {
			const est = e1rm(st.weightKg, st.reps);
			const current = records.find((r) => r.exerciseId === ex.exerciseId);
			if (!current || est > current.e1rm + .01 || st.weightKg > current.weightKg) {
				const next = {
					exerciseId: ex.exerciseId,
					weightKg: st.weightKg,
					reps: st.reps,
					e1rm: est,
					date: new Date(endedAt).toISOString().slice(0, 10)
				};
				const idx = records.findIndex((r) => r.exerciseId === ex.exerciseId);
				if (idx >= 0) records[idx] = next;
				else records.push(next);
				if (!prs.includes(ex.exerciseId)) prs.push(ex.exerciseId);
			}
		}
		const logged = {
			id: uid("ses"),
			routineId: s.session.routineId,
			routineName: s.session.routineName,
			startedAt: s.session.startedAt,
			endedAt,
			volumeKg,
			setsCompleted,
			exercises,
			prs
		};
		set({
			session: null,
			lastSummary: logged,
			history: [logged, ...s.history].slice(0, 200),
			records,
			tab: "home"
		});
		return logged;
	},
	saveCustomRoutine: (routine) => set((s) => ({ customRoutines: [routine, ...s.customRoutines.filter((r) => r.id !== routine.id)] })),
	deleteCustomRoutine: (id) => set((s) => ({ customRoutines: s.customRoutines.filter((r) => r.id !== id) })),
	addBodyLog: (weightKg) => set((s) => {
		const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		return {
			bodyLogs: [...s.bodyLogs.filter((l) => l.date !== date), {
				date,
				weightKg
			}].sort((a, b) => a.date.localeCompare(b.date)),
			profile: {
				...s.profile,
				bodyWeightKg: weightKg
			}
		};
	}),
	setTimerMode: (timerMode) => set({ timerMode }),
	resetAll: () => set({
		profile: defaultProfile,
		customRoutines: [],
		history: [],
		records: [],
		bodyLogs: [],
		session: null,
		lastSummary: null,
		tab: "home"
	})
}), {
	name: "trainup-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		profile: s.profile,
		customRoutines: s.customRoutines,
		history: s.history,
		records: s.records,
		bodyLogs: s.bodyLogs,
		session: s.session,
		timerMode: s.timerMode
	})
}));
function PhoneShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-chassis",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex h-dvh w-full flex-col overflow-hidden bg-bg text-fg sm:h-device sm:w-device sm:rounded-2xl sm:shadow-[var(--shadow-border),0_40px_80px_rgb(0_0_0_/_0.55)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 z-30 hidden h-11 items-center justify-between px-6 text-[11px] font-medium text-fg/80 sm:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: "9:41"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-1.5 h-5 w-24 -translate-x-1/2 rounded-full bg-chassis" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-2.5 w-4 rounded-sm bg-fg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-2.5 w-5 rounded-sm bg-fg/85" })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex min-h-0 flex-1 flex-col",
				children
			})]
		})
	});
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-end gap-0.5", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 rounded-sm bg-fg/40 h-2.5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 rounded-sm bg-fg/70 h-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 rounded-sm bg-accent h-6" })
		]
	});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-1 flex-col items-center justify-center bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 font-display text-4xl tracking-tight",
				children: "TRAINUP"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "El trabajo, registrado."
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none pressable disabled:opacity-40 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)]",
			ghost: "bg-transparent text-fg",
			danger: "bg-danger text-fg"
		},
		size: {
			sm: "h-10 px-3.5 text-sm rounded-md",
			md: "h-12 px-4 text-sm rounded-lg",
			lg: "h-14 px-5 text-base rounded-xl",
			icon: "size-11 rounded-lg"
		},
		block: {
			true: "w-full",
			false: ""
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md",
		block: false
	}
});
function Button({ className, variant, size, block, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size,
			block
		}), className),
		...props
	});
}
var GOALS$1 = [
	"fuerza",
	"hipertrofia",
	"definicion",
	"resistencia"
];
var LEVELS$1 = [
	"principiante",
	"intermedio",
	"avanzado"
];
var DAYS$1 = [
	3,
	4,
	5,
	6
];
function Onboarding() {
	const complete = useTrain((s) => s.completeOnboarding);
	const [step, setStep] = (0, import_react.useState)(0);
	const [name, setName] = (0, import_react.useState)("");
	const [goal, setGoal] = (0, import_react.useState)("hipertrofia");
	const [level, setLevel] = (0, import_react.useState)("intermedio");
	const [days, setDays] = (0, import_react.useState)(4);
	const [unit, setUnit] = (0, import_react.useState)("kg");
	const [weight, setWeight] = (0, import_react.useState)("75");
	function next() {
		if (step === 1 && !name.trim()) return;
		if (step < 3) setStep(step + 1);
		else complete({
			name: name.trim(),
			goal,
			level,
			daysPerWeek: days,
			unit,
			bodyWeightKg: unit === "kg" ? Number(weight) || 75 : (Number(weight) || 165) / 2.20462262
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative flex h-full min-h-0 flex-1 flex-col bg-bg",
		children: step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-h-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/media/gym-hero.jpg",
					alt: "",
					className: "media absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-bg via-bg/55 to-bg/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex h-full flex-col justify-end px-6 pb-10 pt-16 stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-6 font-display text-6xl leading-none tracking-tight",
							children: [
								"TRAIN",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"UP"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xs text-base text-fg/80",
							children: "Sesiones claras, descanso preciso y un registro que no se pierde."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							block: true,
							className: "mt-8",
							onClick: next,
							children: "Empezar"
						})
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col px-6 pb-8 pt-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-[0.2em] text-muted",
					children: [
						"Paso ",
						step,
						" de 3"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-1 overflow-hidden rounded-full bg-elevated",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent transition-[width] duration-200 ease-[var(--ease-out-smooth)]",
						style: { width: `${step / 3 * 100}%` }
					})
				}),
				step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl tracking-tight",
							children: "¿Cómo te llamamos?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Solo para saludarte al entrar."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Tu nombre",
							className: "mt-8 h-14 w-full rounded-xl bg-elevated px-4 text-lg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus:shadow-[var(--shadow-border-hover)]"
						})
					]
				}) : null,
				step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl tracking-tight",
							children: "Objetivo y nivel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Armamos el plan de la semana con esto."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-xs uppercase tracking-wider text-muted",
							children: "Objetivo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: GOALS$1.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								active: goal === g,
								onClick: () => setGoal(g),
								children: GOAL_LABEL[g]
							}, g))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs uppercase tracking-wider text-muted",
							children: "Nivel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-3 gap-2",
							children: LEVELS$1.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								active: level === l,
								onClick: () => setLevel(l),
								children: LEVEL_LABEL[l]
							}, l))
						})
					]
				}) : null,
				step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl tracking-tight",
							children: "Tu semana"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Días de entrenamiento, unidad y peso actual."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-xs uppercase tracking-wider text-muted",
							children: "Días por semana"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-4 gap-2",
							children: DAYS$1.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								active: days === d,
								onClick: () => setDays(d),
								children: d
							}, d))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted",
								children: "Unidad"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									active: unit === "kg",
									onClick: () => setUnit("kg"),
									children: "kg"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									active: unit === "lb",
									onClick: () => setUnit("lb"),
									children: "lb"
								})]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted",
								children: "Peso"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								value: weight,
								onChange: (e) => setWeight(e.target.value),
								className: "mt-2 h-12 w-full rounded-lg bg-elevated px-3 tabular-nums shadow-[var(--shadow-border)] outline-none"
							})] })]
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex gap-3 pt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "flex-1",
						onClick: () => setStep(step - 1),
						children: "Atrás"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-[1.4]",
						onClick: next,
						disabled: step === 1 && !name.trim(),
						children: step === 3 ? "Armar plan" : "Continuar"
					})]
				})
			]
		})
	});
}
function Choice({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-12 rounded-lg text-sm font-medium pressable shadow-[var(--shadow-border)]", active ? "bg-accent text-accent-fg" : "bg-elevated text-fg"),
		children
	});
}
var ITEMS = [
	{
		id: "home",
		label: "Inicio",
		icon: House
	},
	{
		id: "train",
		label: "Entrenar",
		icon: Dumbbell
	},
	{
		id: "timer",
		label: "Timer",
		icon: Timer
	},
	{
		id: "progress",
		label: "Progreso",
		icon: Activity
	},
	{
		id: "profile",
		label: "Yo",
		icon: User
	}
];
function TabBar({ tab, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "safe-bottom shrink-0 border-t border-line bg-surface/95 px-2 pt-1.5 pb-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-5",
			children: ITEMS.map((item) => {
				const active = tab === item.id;
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onChange(item.id),
					className: cn("flex h-14 w-full flex-col items-center justify-center gap-0.5 rounded-md pressable", active ? "text-accent" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: active ? 2.4 : 1.8
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-medium tracking-wide",
						children: item.label
					})]
				}) }, item.id);
			})
		})
	});
}
function Ring({ value, size = 72, stroke = 6, label, sub }) {
	const r = (size - stroke) / 2;
	const c = 2 * Math.PI * r;
	const dash = c * (1 - Math.min(1, Math.max(0, value)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: size,
			height: size,
			className: "-rotate-90",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r,
				fill: "none",
				stroke: "currentColor",
				className: "text-elevated",
				strokeWidth: stroke
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r,
				fill: "none",
				stroke: "currentColor",
				className: "text-accent",
				strokeWidth: stroke,
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: dash
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg leading-none tabular-nums",
				children: label
			}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] uppercase tracking-wider text-muted",
				children: sub
			}) : null]
		})]
	});
}
function HomeView() {
	const profile = useTrain((s) => s.profile);
	const history = useTrain((s) => s.history);
	const extras = useTrain((s) => s.customRoutines);
	const records = useTrain((s) => s.records);
	const startRoutine = useTrain((s) => s.startRoutine);
	const setTab = useTrain((s) => s.setTab);
	const lastSummary = useTrain((s) => s.lastSummary);
	const today = todaysRoutine(profile, history, extras);
	const streak = computeStreak(history);
	const weekStart = startOfLocalWeek();
	const weekSessions = history.filter((h) => h.endedAt >= weekStart);
	const trainedToday = history.some((h) => isToday(h.endedAt));
	const weekVol = weekSessions.reduce((s, h) => s + h.volumeKg, 0);
	const last = history[0];
	const latestPr = records[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.18em] text-muted",
					children: longDate()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-1 font-display text-4xl leading-none tracking-tight",
					children: [
						greeting(),
						", ",
						firstName(profile.name)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
					value: weekSessions.length / profile.daysPerWeek,
					label: `${weekSessions.length}/${profile.daysPerWeek}`,
					sub: "semana"
				})]
			}),
			lastSummary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-elevated px-4 py-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-accent",
						children: "Sesión cerrada"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium",
						children: lastSummary.routineName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatDuration(lastSummary.endedAt - lastSummary.startedAt),
							" ·",
							" ",
							formatVolume(lastSummary.volumeKg, profile.unit),
							" · ",
							lastSummary.setsCompleted,
							" series",
							lastSummary.prs.length ? ` · ${lastSummary.prs.length} PR` : ""
						]
					})
				]
			}) : null,
			today ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => startRoutine(today),
				className: "group relative block w-full overflow-hidden rounded-2xl text-left pressable",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: COVER_SRC[today.cover],
						alt: "",
						className: "media h-56 w-full object-cover transition-transform duration-500 group-active:scale-105"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-bg via-bg/50 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.2em] text-accent",
								children: trainedToday ? "Hecho hoy" : "Hoy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-4xl leading-none",
								children: today.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-fg/80",
								children: [
									today.focus,
									" · ",
									today.durationMin,
									" min · ",
									today.exercises.length,
									" ejercicios"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-4 inline-flex h-11 items-center rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg",
								children: trainedToday ? "Repetir sesión" : "Empezar"
							})
						]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Racha",
						value: `${streak}d`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-3.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Volumen",
						value: formatVolume(weekVol, profile.unit)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "PRs",
						value: String(records.length),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-3.5" })
					})
				]
			}),
			last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xs uppercase tracking-[0.18em] text-muted",
					children: "Última sesión"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-0.5 text-xs text-muted",
					onClick: () => setTab("progress"),
					children: ["Historial ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab("progress"),
				className: "flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3.5 text-left shadow-[var(--shadow-border)] pressable",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: last.routineName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						formatVolume(last.volumeKg, profile.unit),
						" · ",
						last.setsCompleted,
						" series"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tabular-nums text-muted",
					children: formatDuration(last.endedAt - last.startedAt)
				})]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "El primer entrenamiento es el que cuenta."
			}),
			latestPr ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					"Mejor marca reciente · ",
					formatWeight(latestPr.weightKg, profile.unit),
					" × ",
					latestPr.reps
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				block: true,
				onClick: () => setTab("train"),
				children: "Ver todas las rutinas"
			})
		]
	});
}
function Stat({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted",
			children: [icon, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl leading-none tabular-nums",
			children: value
		})]
	});
}
function startOfLocalWeek() {
	const d = /* @__PURE__ */ new Date();
	const diff = (d.getDay() + 6) % 7;
	d.setHours(0, 0, 0, 0);
	d.setDate(d.getDate() - diff);
	return d.getTime();
}
var MUSCLES = [
	"todos",
	"pecho",
	"espalda",
	"hombros",
	"piernas",
	"gluteos",
	"biceps",
	"triceps",
	"core",
	"cardio"
];
function TrainView() {
	const profile = useTrain((s) => s.profile);
	const extras = useTrain((s) => s.customRoutines);
	const startRoutine = useTrain((s) => s.startRoutine);
	const deleteCustom = useTrain((s) => s.deleteCustomRoutine);
	const [mode, setMode] = (0, import_react.useState)("rutinas");
	const catalog = filterRoutines(profile.level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl tracking-tight",
					children: "Entrenar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-3 gap-1 rounded-xl bg-surface p-1 shadow-[var(--shadow-border)]",
					children: [
						["rutinas", "Rutinas"],
						["libreria", "Librería"],
						["crear", "Crear"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMode(id),
						className: cn("h-10 rounded-lg text-sm font-medium pressable", mode === id ? "bg-elevated text-fg" : "text-muted"),
						children: label
					}, id))
				})]
			}),
			mode === "rutinas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 pb-8 stagger-in",
				children: [
					extras.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.18em] text-muted",
						children: "Tuyas"
					}) : null,
					extras.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoutineCard, {
						routine: r,
						onStart: () => startRoutine(r),
						onDelete: () => deleteCustom(r.id)
					}, r.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-2 text-xs uppercase tracking-[0.18em] text-muted",
						children: "Programas"
					}),
					catalog.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoutineCard, {
						routine: r,
						onStart: () => startRoutine(r)
					}, r.id))
				]
			}) : null,
			mode === "libreria" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, { onPick: (id) => startSingle(id, startRoutine) }) : null,
			mode === "crear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Creator, { onDone: () => setMode("rutinas") }) : null
		]
	});
}
function startSingle(exerciseId, start) {
	const ex = getExercise(exerciseId);
	start({
		id: `solo-${ex.id}`,
		name: ex.name,
		focus: MUSCLE_LABEL[ex.muscle],
		durationMin: 20,
		level: "intermedio",
		cover: "barbell",
		exercises: [{
			exerciseId: ex.id,
			sets: ex.defaultSets,
			reps: ex.defaultReps,
			restSec: ex.restSec
		}]
	});
}
function RoutineCard({ routine, onStart, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onStart,
			className: "block w-full text-left pressable",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: COVER_SRC[routine.cover],
					alt: "",
					className: "media h-full w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-surface to-transparent" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pb-4 pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl leading-none",
						children: routine.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							routine.focus,
							" · ",
							routine.durationMin,
							" min · ",
							LEVEL_LABEL[routine.level]
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-0.5 rounded-full bg-elevated px-2.5 py-1 text-[11px] tabular-nums text-muted",
						children: [routine.exercises.length, " ej."]
					})]
				})
			})]
		}), onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end px-3 pb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onDelete,
				className: "flex size-11 items-center justify-center rounded-lg text-muted pressable",
				"aria-label": "Eliminar rutina",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
			})
		}) : null]
	});
}
function Library({ onPick, hideStartHint }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [muscle, setMuscle] = (0, import_react.useState)("todos");
	const list = (0, import_react.useMemo)(() => searchExercises(q, muscle), [q, muscle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar ejercicio",
					className: "h-12 w-full rounded-xl bg-elevated pl-10 pr-3 text-sm shadow-[var(--shadow-border)] outline-none placeholder:text-subtle"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1.5 overflow-x-auto pb-1",
				children: MUSCLES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setMuscle(m),
					className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium pressable", muscle === m ? "bg-accent text-accent-fg" : "bg-elevated text-muted"),
					children: m === "todos" ? "Todos" : MUSCLE_LABEL[m]
				}, m))
			}),
			!hideStartHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "Toca para entrenar ese movimiento solo."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: list.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPick(ex.id),
					className: "flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-border)] pressable",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium",
						children: ex.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [
							MUSCLE_LABEL[ex.muscle],
							" · ",
							EQUIPMENT_LABEL[ex.equipment]
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs tabular-nums text-muted",
						children: [
							ex.defaultSets,
							"×",
							ex.defaultReps
						]
					})]
				}) }, ex.id))
			})
		]
	});
}
function Creator({ onDone }) {
	const save = useTrain((s) => s.saveCustomRoutine);
	const [name, setName] = (0, import_react.useState)("Mi rutina");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [open, setOpen] = (0, import_react.useState)(false);
	function add(id) {
		const ex = getExercise(id);
		setPicked((p) => [...p, {
			exerciseId: id,
			sets: ex.defaultSets,
			reps: ex.defaultReps,
			restSec: ex.restSec
		}]);
		setOpen(false);
	}
	function persist() {
		if (!name.trim() || picked.length === 0) return;
		save({
			id: uid("rut"),
			name: name.trim(),
			focus: "Personal",
			durationMin: Math.max(20, picked.length * 8),
			level: "intermedio",
			cover: "dumbbells",
			custom: true,
			exercises: picked
		});
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: name,
				onChange: (e) => setName(e.target.value),
				className: "h-12 w-full rounded-xl bg-elevated px-4 shadow-[var(--shadow-border)] outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: picked.map((slot, i) => {
					const ex = getExercise(slot.exerciseId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: ex.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [
								slot.sets,
								" × ",
								slot.reps
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "size-11 text-muted",
							onClick: () => setPicked((p) => p.filter((_, idx) => idx !== i)),
							"aria-label": "Quitar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, `${slot.exerciseId}-${i}`);
				})
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, {
				hideStartHint: true,
				onPick: add
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				block: true,
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Añadir ejercicio"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				block: true,
				disabled: !picked.length,
				onClick: persist,
				children: "Guardar rutina"
			})
		]
	});
}
var ctx = null;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor();
	}
	return ctx;
}
function chime(kind = "done") {
	const audio = getCtx();
	if (!audio) return;
	audio.resume();
	const now = audio.currentTime;
	(kind === "tick" ? [660] : [
		523,
		784,
		1046
	]).forEach((freq, i) => {
		const osc = audio.createOscillator();
		const gain = audio.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		const t = now + i * .12;
		gain.gain.setValueAtTime(1e-4, t);
		gain.gain.exponentialRampToValueAtTime(.07, t + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + .22);
		osc.connect(gain);
		gain.connect(audio.destination);
		osc.start(t);
		osc.stop(t + .24);
	});
}
function pulse() {
	if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate([
		28,
		40,
		48
	]);
}
function Stepper({ value, onChange, step = 1, min = 0, suffix, wide }) {
	const shown = Number.isInteger(value) ? String(value) : value.toFixed(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-12 items-center rounded-lg bg-elevated shadow-[var(--shadow-border)]", wide ? "min-w-0 flex-1" : "min-w-24"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-12 items-center justify-center text-muted pressable",
				"aria-label": "Restar",
				onClick: () => onChange(Math.max(min, Math.round((value - step) * 10) / 10)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl leading-none tabular-nums",
					children: shown
				}), suffix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase tracking-wider text-muted",
					children: suffix
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-12 items-center justify-center text-muted pressable",
				"aria-label": "Sumar",
				onClick: () => onChange(Math.round((value + step) * 10) / 10),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})
		]
	});
}
function SessionView() {
	const session = useTrain((s) => s.session);
	const unit = useTrain((s) => s.profile.unit);
	const skipRest = useTrain((s) => s.skipRest);
	const addRest = useTrain((s) => s.addRest);
	const setCurrent = useTrain((s) => s.setCurrentExercise);
	const toggleSet = useTrain((s) => s.toggleSet);
	const updateSet = useTrain((s) => s.updateSet);
	const addSet = useTrain((s) => s.addSet);
	const removeSet = useTrain((s) => s.removeSet);
	const replaceExercise = useTrain((s) => s.replaceExercise);
	const finish = useTrain((s) => s.finishSession);
	const discard = useTrain((s) => s.discardSession);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [picker, setPicker] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [rang, setRang] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 200);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!session?.restUntil) {
			setRang(false);
			return;
		}
		if (session.restUntil <= Date.now() && !rang) {
			setRang(true);
			chime("done");
			pulse();
			skipRest();
		}
	}, [
		now,
		session?.restUntil,
		rang,
		skipRest
	]);
	if (!session) return null;
	const current = session.exercises[session.currentIndex];
	const exercise = getExercise(current.exerciseId);
	const remaining = session.restUntil ? Math.max(0, (session.restUntil - now) / 1e3) : 0;
	const resting = remaining > 0;
	const doneSets = session.exercises.reduce((n, ex) => n + ex.sets.filter((s) => s.completed).length, 0);
	const totalSets = session.exercises.reduce((n, ex) => n + ex.sets.length, 0);
	const elapsed = now - session.startedAt;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full min-h-0 flex-1 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 px-4 pt-12 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-lg text-muted pressable",
						onClick: () => setConfirm(true),
						"aria-label": "Cerrar sesión",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs uppercase tracking-[0.18em] text-muted",
							children: session.routineName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-fg",
							children: [
								formatDuration(elapsed),
								" · ",
								doneSets,
								"/",
								totalSets
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 w-20 overflow-hidden rounded-full bg-elevated",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent transition-[width] duration-200",
							style: { width: `${doneSets / Math.max(1, totalSets) * 100}%` }
						})
					})
				]
			}),
			picker ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Sustituir"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setPicker(false),
						children: "Cancelar"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, {
					hideStartHint: true,
					onPick: (id) => {
						replaceExercise(session.currentIndex, id);
						setPicker(false);
					}
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.18em] text-accent",
						children: MUSCLE_LABEL[exercise.muscle]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-5xl leading-none tracking-tight",
						children: exercise.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: exercise.cues.join(" · ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-2",
						children: current.sets.map((st, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("rounded-xl px-3 py-2 shadow-[var(--shadow-border)]", st.completed ? "bg-elevated/70" : "bg-surface"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-6 text-center font-display text-lg tabular-nums text-muted",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										value: toDisplayWeight(st.weightKg, unit),
										step: weightStep(unit),
										suffix: unit,
										wide: true,
										onChange: (n) => updateSet(session.currentIndex, st.id, { weightKg: fromDisplayWeight(n, unit) })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										value: st.reps,
										step: 1,
										min: 0,
										suffix: "reps",
										onChange: (n) => updateSet(session.currentIndex, st.id, { reps: Math.max(0, Math.round(n)) })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => toggleSet(session.currentIndex, st.id),
										className: cn("flex size-12 shrink-0 items-center justify-center rounded-lg pressable", st.completed ? "bg-accent text-accent-fg" : "bg-elevated text-muted"),
										"aria-label": st.completed ? "Desmarcar serie" : "Completar serie",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" })
									})
								]
							})
						}, st.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								className: "flex-1",
								onClick: () => addSet(session.currentIndex),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Serie"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								className: "flex-1",
								onClick: () => setPicker(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Replace, { className: "size-4" }), "Cambiar"]
							}),
							current.sets.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => removeSet(session.currentIndex, current.sets.at(-1).id),
								children: "Quitar"
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "safe-bottom shrink-0 border-t border-line px-4 pt-3 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-12 items-center justify-center rounded-lg bg-elevated pressable disabled:opacity-30",
							disabled: session.currentIndex === 0,
							onClick: () => setCurrent(session.currentIndex - 1),
							"aria-label": "Anterior",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-muted",
							children: [
								session.currentIndex + 1,
								" / ",
								session.exercises.length
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-12 items-center justify-center rounded-lg bg-elevated pressable disabled:opacity-30",
							disabled: session.currentIndex >= session.exercises.length - 1,
							onClick: () => setCurrent(session.currentIndex + 1),
							"aria-label": "Siguiente",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					block: true,
					size: "lg",
					onClick: () => finish(),
					children: "Terminar sesión"
				})]
			}),
			resting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex flex-col justify-end bg-bg/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-t-2xl bg-surface px-6 pb-10 pt-6 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-xs uppercase tracking-[0.2em] text-muted",
							children: "Descanso"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
								size: 168,
								stroke: 8,
								value: session.restTotalSec ? 1 - remaining / session.restTotalSec : 0,
								label: formatClock(remaining),
								sub: "rest"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-center text-sm text-muted",
							children: ["Siguiente: ", formatWeight(current.sets.find((s) => !s.completed)?.weightKg ?? 0, unit)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => addRest(-15),
									children: "−15s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => skipRest(),
									children: "Saltar"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => addRest(15),
									children: "+15s"
								})
							]
						})
					]
				})
			}) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-30 flex items-end bg-bg/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full rounded-t-2xl bg-surface px-5 pb-8 pt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "¿Salir sin guardar?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Las series de esta sesión no se registrarán."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								className: "flex-1",
								onClick: () => setConfirm(false),
								children: "Seguir"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								className: "flex-1",
								onClick: discard,
								children: "Descartar"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-2",
							block: true,
							onClick: () => finish(),
							children: "Guardar y salir"
						})
					]
				})
			}) : null
		]
	});
}
var MODES = [
	{
		id: "descanso",
		label: "Rest"
	},
	{
		id: "tabata",
		label: "Tabata"
	},
	{
		id: "emom",
		label: "EMOM"
	},
	{
		id: "amrap",
		label: "AMRAP"
	},
	{
		id: "cronometro",
		label: "Cronó"
	}
];
function TimerView() {
	const mode = useTrain((s) => s.timerMode);
	const setMode = useTrain((s) => s.setTimerMode);
	const [seconds, setSeconds] = (0, import_react.useState)(90);
	const [work, setWork] = (0, import_react.useState)(20);
	const [rest, setRest] = (0, import_react.useState)(10);
	const [rounds, setRounds] = (0, import_react.useState)(8);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const [phase, setPhase] = (0, import_react.useState)("work");
	const [round, setRound] = (0, import_react.useState)(1);
	const started = (0, import_react.useRef)(null);
	const acc = (0, import_react.useRef)(0);
	const ended = (0, import_react.useRef)(false);
	const target = (0, import_react.useMemo)(() => {
		if (mode === "descanso") return seconds;
		if (mode === "amrap") return seconds;
		if (mode === "emom") return rounds * 60;
		if (mode === "tabata") return rounds * (work + rest);
		return 0;
	}, [
		mode,
		seconds,
		rounds,
		work,
		rest
	]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => {
			const now = Date.now();
			if (started.current == null) started.current = now;
			const t = acc.current + (now - started.current) / 1e3;
			setElapsed(t);
		}, 100);
		return () => window.clearInterval(id);
	}, [running]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		if (mode === "cronometro") return;
		if (ended.current) return;
		if (mode === "descanso" || mode === "amrap") {
			if (elapsed >= target) finishBlock();
			return;
		}
		if (mode === "emom") {
			const r = Math.floor(elapsed / 60) + 1;
			if (r !== round && r <= rounds) {
				setRound(r);
				chime("tick");
				pulse();
			}
			if (elapsed >= target) finishBlock();
			return;
		}
		if (mode === "tabata") {
			const cycle = work + rest;
			const pos = elapsed % cycle;
			const r = Math.min(rounds, Math.floor(elapsed / cycle) + 1);
			const nextPhase = pos < work ? "work" : "rest";
			if (nextPhase !== phase) {
				setPhase(nextPhase);
				chime(nextPhase === "work" ? "tick" : "done");
				pulse();
			}
			if (r !== round) setRound(r);
			if (elapsed >= target) finishBlock();
		}
	}, [
		elapsed,
		running,
		mode,
		target,
		work,
		rest,
		rounds,
		phase,
		round
	]);
	function finishBlock() {
		if (ended.current) return;
		ended.current = true;
		setRunning(false);
		acc.current = target;
		setElapsed(target);
		started.current = null;
		chime("done");
		pulse();
	}
	function toggle() {
		if (running) {
			acc.current = elapsed;
			started.current = null;
			setRunning(false);
		} else {
			if (elapsed >= target && mode !== "cronometro") reset();
			started.current = Date.now();
			setRunning(true);
		}
	}
	function reset() {
		setRunning(false);
		setElapsed(0);
		acc.current = 0;
		started.current = null;
		ended.current = false;
		setPhase("work");
		setRound(1);
	}
	function switchMode(next) {
		reset();
		setMode(next);
		if (next === "tabata") {
			setWork(20);
			setRest(10);
			setRounds(8);
		}
		if (next === "emom") setRounds(10);
		if (next === "amrap") setSeconds(600);
		if (next === "descanso") setSeconds(90);
	}
	const remaining = mode === "cronometro" ? elapsed : Math.max(0, target - elapsed);
	const progress = mode === "cronometro" ? 0 : target ? Math.min(1, elapsed / target) : 0;
	const label = mode === "tabata" ? phase === "work" ? "WORK" : "REST" : mode === "emom" ? `R${round}` : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl tracking-tight",
				children: "Timer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1 overflow-x-auto",
				children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => switchMode(m.id),
					className: cn("h-10 shrink-0 rounded-full px-3 text-xs font-medium pressable", mode === m.id ? "bg-accent text-accent-fg" : "bg-elevated text-muted"),
					children: m.label
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
					size: 220,
					stroke: 10,
					value: progress,
					label: formatClock(remaining),
					sub: label
				}), mode === "tabata" || mode === "emom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Ronda ",
						round,
						" / ",
						rounds
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-3",
				children: [
					mode === "descanso" || mode === "amrap" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: mode === "amrap" ? "Minutos" : "Segundos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							value: mode === "amrap" ? Math.round(seconds / 60) : seconds,
							step: mode === "amrap" ? 1 : 15,
							min: mode === "amrap" ? 1 : 15,
							onChange: (n) => setSeconds(mode === "amrap" ? n * 60 : n)
						})]
					}) : null,
					mode === "tabata" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Work",
							value: work,
							step: 5,
							onChange: setWork
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Rest",
							value: rest,
							step: 5,
							onChange: setRest
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Rondas",
							value: rounds,
							step: 1,
							onChange: setRounds
						})
					] }) : null,
					mode === "emom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Minutos",
						value: rounds,
						step: 1,
						min: 1,
						onChange: setRounds
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex gap-2 pt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "lg",
					className: "flex-1",
					onClick: reset,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "flex-[1.4]",
					onClick: toggle,
					children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), running ? "Pausa" : "Start"]
				})]
			})
		]
	});
}
function Row({ label, value, step, min = 0, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
			value,
			step,
			min,
			onChange
		})]
	});
}
function ProgressView() {
	const history = useTrain((s) => s.history);
	const records = useTrain((s) => s.records);
	const unit = useTrain((s) => s.profile.unit);
	const bodyLogs = useTrain((s) => s.bodyLogs);
	const weekData = (0, import_react.useMemo)(() => {
		return Array.from({ length: 8 }, (_, i) => {
			const d = subDays(/* @__PURE__ */ new Date(), 7 - i);
			const key = format(d, "yyyy-MM-dd");
			const vol = history.filter((h) => format(h.endedAt, "yyyy-MM-dd") === key).reduce((s, h) => s + h.volumeKg, 0);
			return {
				day: format(d, "EE", { locale: es }).slice(0, 2),
				vol: unit === "kg" ? Math.round(vol) : Math.round(vol * 2.2)
			};
		});
	}, [history, unit]);
	const heat = (0, import_react.useMemo)(() => {
		const set = new Set(history.map((h) => format(h.endedAt, "yyyy-MM-dd")));
		return Array.from({ length: 84 }, (_, i) => {
			const d = subDays(/* @__PURE__ */ new Date(), 83 - i);
			const key = format(d, "yyyy-MM-dd");
			return {
				key,
				on: set.has(key)
			};
		});
	}, [history]);
	const totalVol = history.reduce((s, h) => s + h.volumeKg, 0);
	const lastWeight = bodyLogs.at(-1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7 pb-8 stagger-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl tracking-tight",
				children: "Progreso"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					history.length,
					" sesiones · ",
					formatVolume(totalVol, unit),
					" acumuladas"
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.18em] text-muted",
					children: "Volumen · 8 días"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: weekData,
							margin: {
								top: 8,
								right: 4,
								left: -24,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
									id: "vol",
									x1: "0",
									y1: "0",
									x2: "0",
									y2: "1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "#6EE7B7",
										stopOpacity: .45
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "#6EE7B7",
										stopOpacity: 0
									})]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "day",
									tick: {
										fill: "#8a9086",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fill: "#8a9086",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									contentStyle: {
										background: "#1b1e1b",
										border: "1px solid rgba(237,238,233,0.1)",
										borderRadius: 12,
										color: "#edeee9"
									},
									formatter: (v) => [`${v} ${unit}`, "Volumen"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "vol",
									stroke: "#6EE7B7",
									fill: "url(#vol)",
									strokeWidth: 2
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.18em] text-muted",
				children: "Calendario"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-7 gap-1.5",
				children: heat.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					title: d.key,
					className: `h-3.5 rounded-sm ${d.on ? "bg-accent" : "bg-elevated"}`
				}, d.key))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.18em] text-muted",
				children: "Marcas personales"
			}), records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Todavía no hay PRs. Ciérralos en la sesión."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: records.slice().sort((a, b) => b.e1rm - a.e1rm).slice(0, 8).map((r) => {
					const ex = getExercise(r.exerciseId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: ex.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: r.date
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-xl tabular-nums",
							children: [formatWeight(r.weightKg, unit, false), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-1 text-xs text-muted",
								children: [
									unit,
									" × ",
									r.reps
								]
							})]
						})]
					}, r.exerciseId);
				})
			})] }),
			lastWeight ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Peso corporal · ", formatWeight(lastWeight.weightKg, unit)]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.18em] text-muted",
				children: "Historial"
			}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Cuando termines una sesión, aparece aquí."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: history.slice(0, 12).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: h.routineName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tabular-nums text-muted",
							children: format(h.endedAt, "d MMM", { locale: es })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							formatDuration(h.endedAt - h.startedAt),
							" · ",
							formatVolume(h.volumeKg, unit),
							" ·",
							" ",
							h.setsCompleted,
							" series",
							h.prs.length ? ` · ${h.prs.length} PR` : ""
						]
					})]
				}, h.id))
			})] })
		]
	});
}
var GOALS = [
	"fuerza",
	"hipertrofia",
	"definicion",
	"resistencia"
];
var LEVELS = [
	"principiante",
	"intermedio",
	"avanzado"
];
var DAYS = [
	3,
	4,
	5,
	6
];
function ProfileView() {
	const profile = useTrain((s) => s.profile);
	const history = useTrain((s) => s.history);
	const update = useTrain((s) => s.updateProfile);
	const addBodyLog = useTrain((s) => s.addBodyLog);
	const resetAll = useTrain((s) => s.resetAll);
	const [weight, setWeight] = (0, import_react.useState)(String(toDisplayWeight(profile.bodyWeightKg, profile.unit)));
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	function saveWeight() {
		const n = Number(weight);
		if (!Number.isFinite(n) || n <= 0) return;
		addBodyLog(fromDisplayWeight(n, profile.unit));
	}
	function setUnit(unit) {
		update({ unit });
		setWeight(String(toDisplayWeight(profile.bodyWeightKg, unit)));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-14 items-center justify-center rounded-xl bg-elevated shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl leading-none tracking-tight",
					children: profile.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						GOAL_LABEL[profile.goal],
						" · ",
						LEVEL_LABEL[profile.level],
						" · ",
						history.length,
						" sesiones"
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nombre",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: profile.name,
					onChange: (e) => update({ name: e.target.value }),
					className: "h-12 w-full rounded-xl bg-elevated px-4 shadow-[var(--shadow-border)] outline-none"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Objetivo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: GOALS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: profile.goal === g,
						onClick: () => update({ goal: g }),
						children: GOAL_LABEL[g]
					}, g))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nivel",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: LEVELS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: profile.level === l,
						onClick: () => update({ level: l }),
						children: LEVEL_LABEL[l]
					}, l))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Días por semana",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: DAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: profile.daysPerWeek === d,
						onClick: () => update({ daysPerWeek: d }),
						children: d
					}, d))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Unidad",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: profile.unit === "kg",
						onClick: () => setUnit("kg"),
						children: "Kilogramos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: profile.unit === "lb",
						onClick: () => setUnit("lb"),
						children: "Libras"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: `Peso corporal (${profile.unit})`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: weight,
						onChange: (e) => setWeight(e.target.value),
						className: "h-12 flex-1 rounded-xl bg-elevated px-4 tabular-nums shadow-[var(--shadow-border)] outline-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: saveWeight,
						children: "Guardar"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-muted",
					children: ["Actual: ", formatWeight(profile.bodyWeightKg, profile.unit)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-2xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "TrainUp guarda todo en este dispositivo. Añádela a tu pantalla de inicio para usarla como app."
				})
			}),
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: "Esto borra historial, PRs y el perfil."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "flex-1",
						onClick: () => setConfirm(false),
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						className: "flex-1",
						onClick: resetAll,
						children: "Borrar"
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				block: true,
				onClick: () => setConfirm(true),
				children: "Borrar datos locales"
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-xs uppercase tracking-[0.18em] text-muted",
		children: label
	}), children] });
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-11 rounded-lg text-sm font-medium pressable shadow-[var(--shadow-border)]", active ? "bg-accent text-accent-fg" : "bg-elevated text-fg"),
		children
	});
}
function Home() {
	const hydrated = useTrain((s) => s.hydrated);
	const onboarded = useTrain((s) => s.profile.onboarded);
	const session = useTrain((s) => s.session);
	const tab = useTrain((s) => s.tab);
	const setTab = useTrain((s) => s.setTab);
	const skipRest = useTrain((s) => s.skipRest);
	(0, import_react.useEffect)(() => {
		useTrain.persist.rehydrate().then(() => {
			const rest = useTrain.getState().session?.restUntil;
			if (rest && rest < Date.now()) skipRest();
			useTrain.getState().markHydrated();
		});
	}, [skipRest]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneShell, { children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {}) : !onboarded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {}) : session ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "min-h-0 flex-1 overflow-y-auto px-5 pt-12",
			children: [
				tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}) : null,
				tab === "train" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrainView, {}) : null,
				tab === "timer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerView, {}) : null,
				tab === "progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressView, {}) : null,
				tab === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileView, {}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabBar, {
			tab,
			onChange: setTab
		})]
	}) });
}
//#endregion
export { Home as component };
